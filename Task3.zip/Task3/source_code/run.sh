python D:/Task3/source_code/code_and_checkpoints/Task3.py "$@"
