
from ultralytics import YOLO
import cv2
import csv
import numpy as np
import pandas as pd
import time
from collections import defaultdict
import os,shutil
import ultralytics.utils.torch_utils
import sys
def is_circle(points, threshold=0.95):
    if len(points) < 3:
        return False

    x = points.iloc[:, 0]
    y = points.iloc[:, 1]

    # Calculate the center of the points
    center_x = x.mean()
    center_y = y.mean()

    # Calculate the radius and the residuals
    radius = np.sqrt(((x - center_x) ** 2 + (y - center_y) ** 2).mean())
    residuals = np.abs(np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2) - radius)

    # Calculate the R-squared value
    total_variance = np.var(points, axis=0).sum()
    explained_variance = total_variance - np.var(residuals)
    r_squared = explained_variance / total_variance

    return r_squared > threshold

# Function to determine if the object is moving forward
def is_moving_forward(positions):

    if len(positions) < 3:
        return False

    position_diffs = np.diff(positions, axis=0)
    return all(diff[0] > 0 for diff in position_diffs)

def main():
    arguments = sys.argv[1:]
    directory = str(arguments[0])
    weight_path = directory +"source_code/code_and_checkpoints/" + "best.pt"
    model = YOLO(weight_path)
    video_id = arguments[1]  # arguments[1]
    video_path = directory + "data/" + str(video_id) + ".mp4"
    csv_folder = directory + "Csvs"

    cap = cv2.VideoCapture(video_path)
    tracking_id = []
    unique_ids = []
    if not cap.isOpened():
        print("Error: Video capture not opened")
        exit()
    track_history = defaultdict(lambda: [])

    while True:
        ret, frame = cap.read()

        if not ret:
            break
        if ret:
            # Run YOLOv8 tracking on the frame, persisting tracks between frames
            results = model.track(frame, tracker='bytetrack.yaml', persist=True)
            shape = frame.shape

            # Get the boxes and track IDs
            boxes = results[0].boxes.xywh.cpu()
            track_ids = results[0].boxes.id.int().cpu().tolist()

            # Visualize the results on the frame
            annotated_frame = results[0].plot()

            # Plot the tracks
            for box, track_id in zip(boxes, track_ids):
                x, y, w, h = box
                track = track_history[track_id]
                tracking_id.append(track_id)
                track.append((float(x), float(y)))  # x, y center point

                if len(track) > 30:  # retain 90 tracks for 90 frames
                    track.pop(0)
                # Draw the tracking lines
                points = np.hstack(track).astype(np.int32).reshape((-1, 1, 2))

            # Break the loop if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        else:
            # Break the loop if the end of the video is reached
            break

    unique_ids = list(set(tracking_id))
    for i in unique_ids:
        df = pd.DataFrame(track_history[i])

        for j in range(len(df)):
            x = df[0][j]
            y = df[1][j]

        file_path = os.path.join(csv_folder, f"{i}.csv")
        df.to_csv(file_path, columns=[0, 1], index=False, mode='a')

    cap.release()
    cv2.destroyAllWindows()

    count = 0
    circle = 0  # nonprogressive
    forward = 0  # progressive
    not_moving = 0  # immotile


    for filename in os.listdir(csv_folder):
        count += 1
        if filename.endswith(".csv"):
            file_path = os.path.join(csv_folder, filename)
            df = pd.read_csv(file_path)  # Load the CSV data

            if is_circle(df, threshold=0.95):
                circle += 1
            elif is_moving_forward(df):
                forward += 1
            else:
                not_moving += 1

    Progressive_motility = (forward / count) * 100
    Non_progressive_sperm_motility = (circle / count) * 100
    Immotile_sperm = (not_moving / count) * 100
    csv_file_path = directory + "motility_predictions.csv"


    new_data = {
        'ID': video_id,
        'Progressive motility (%)': Progressive_motility,
        'Non progressive sperm motility (%)': Non_progressive_sperm_motility,
        'Immotile sperm (%)': Immotile_sperm
    }
    file_exists = False
    try:
        with open(csv_file_path, 'r') as file:
            reader = csv.reader(file)
            file_exists = bool(next(reader, None))
    except FileNotFoundError:
        pass

    # Open the CSV file in append mode
    with open(csv_file_path, 'a', newline='') as file:
        fieldnames = list(new_data.keys())
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        # Write headers if the file is empty
        if not file_exists:
            writer.writeheader()

        # Write the values of the dictionary
        writer.writerow(new_data)

    for filename in os.listdir(csv_folder):
        file_path = os.path.join(csv_folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))


if __name__ == '__main__':
    main()

