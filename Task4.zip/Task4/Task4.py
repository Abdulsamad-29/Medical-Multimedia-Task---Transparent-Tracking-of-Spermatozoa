import os
import glob
import networkx as nx
import numpy as np
import pandas as pd
import xml.etree.ElementTree as ET
from collections import defaultdict

video_id = input("Enter video id")
# Directory containing GraphML files
directory_path = f"E:/media eval 2023 spermatoaza papers/test_data_graphs/spatial_threshold_0.5/{video_id}/frame_graphs"

# all_node_data = defaultdict(list)
df = pd.DataFrame(columns=['node_id', 'x_center', 'y_center'])
# df1 = pd.DataFrame(columns=['node_id', 'x_center', 'y_center'])


for filename in os.listdir(directory_path):
    if filename.endswith(".graphml"):
        file_path = os.path.join(directory_path, filename)

        # Read GraphML file using the provided format
        root = ET.parse(file_path).getroot()

        # Dictionary to store node data for the current file
        # node_data = {}
        # node_data2 = {}

        for node_element in root.findall(".//{http://graphml.graphdrawing.org/xmlns}node"):
            node_id = node_element.get("id")
            frame_number = int(node_element.find(".//{http://graphml.graphdrawing.org/xmlns}data[@key='d0']").text)
            class_id = int(node_element.find(".//{http://graphml.graphdrawing.org/xmlns}data[@key='d1']").text)

            x_center = float(node_element.find(".//{http://graphml.graphdrawing.org/xmlns}data[@key='d2']").text)
            y_center = float(node_element.find(".//{http://graphml.graphdrawing.org/xmlns}data[@key='d3']").text)

            df = df._append({'node_id': node_id, 'x_center': x_center, 'y_center': y_center}, ignore_index=True)

# df = pd.DataFrame(node_data, index=[0])
print(df)
# DataFrame.to_csv(filename, sep=',', index=False, encoding='utf-8')
df.to_csv('df_to_csv.csv')

# -------------------------------------------------------------------------------------------------------------------------

df = pd.read_csv(r"E:/df_to_csv.csv")

df1 = df.node_id.unique()
print(len(df1))

for i in df1:
    df_new = df[df['node_id'] == i]
    df_new = df_new[['node_id', 'x_center', 'y_center']]
    # write dataframe to csv
    df_new.to_csv(f"E:/Task4/csvs/df_{i}.csv")


# ---------------------------------------------------------------------------------------------------------------------------
def analyze_trajectory(x, y):
    # Check if the trajectory resembles a circle or moves forward (linear motion)
    circle_threshold = 0.9  # Tweak this threshold based on your data
    displacement_threshold = 0.1

    # Calculate the mean distance of points to the center
    center = np.mean(x), np.mean(y)
    distances = np.sqrt((x - center[0]) ** 2 + (y - center[1]) ** 2)
    mean_distance = np.mean(distances)

    displacement = np.sqrt((x - x[0]) ** 2 + (y - y[0]) ** 2)

    if np.max(displacement) < displacement_threshold:
        return 'immotile', 1

    elif mean_distance < circle_threshold:
        return 'non-progressive', 1
    else:
        return 'progressive', 1


def process_csv_file(csv_path):
    df = pd.read_csv(csv_path)
    x = df['x_center'].values
    y = df['y_center'].values

    trajectory_type, count = analyze_trajectory(x, y)
    return trajectory_type, count


def process_directory(directory_path, video_id):
    csv_files = [f for f in os.listdir(directory_path) if f.endswith('.csv')]

    total_count = len(csv_files)
    progressive_count = 0
    non_progressive_count = 0
    immotile_count = 0

    for csv_file in csv_files:
        csv_path = os.path.join(directory_path, csv_file)
        trajectory_type, count = process_csv_file(csv_path)

        if trajectory_type == 'progressive':
            progressive_count += count
        elif trajectory_type == 'non-progressive':
            non_progressive_count += count
        elif trajectory_type == 'immotile':
            immotile_count += 1

    immotile_count = total_count - (progressive_count + non_progressive_count)

    progressive_percentage = (progressive_count / total_count) * 100
    non_progressive_percentage = (non_progressive_count / total_count) * 100
    immotile_percentage = (immotile_count / total_count) * 100

    # ------------
    if os.path.exists('motility_predictions.csv'):
        # If the result file already exists, load the existing data
        existing_data = pd.read_csv('motility_predictions.csv')
    else:
        # If the result file doesn't exist, create an empty DataFrame
        existing_data = pd.DataFrame({
            'ID': [],
            'Progressive motility (%)': [],
            'Non-progressive sperm motility (%)': [],
            'Immotile sperm (%)': []
        })

    # Append the new data to the existing DataFrame
    new_data = pd.DataFrame({
        'ID': [video_id],
        'Progressive motility (%)': [progressive_percentage],
        'Non-progressive sperm motility (%)': [non_progressive_percentage],
        'Immotile sperm (%)': [immotile_percentage]
    })

    result = existing_data._append(new_data, ignore_index=True)

    # Save the combined DataFrame to the result file
    result.to_csv('motility_predictions.csv', index=False)

    #     result = pd.DataFrame({
    #         'ID': [video_id],
    #         'Progressive motility (%)': [progressive_percentage],
    #         'Non-progressive sperm motility (%)': [non_progressive_percentage],
    #         'Immotile sperm (%)': [immotile_percentage]
    #     })

    #     result.to_csv('result.csv', index=False)

    # ----------------------


if __name__ == "__main__":
    directory_path = f"D:/Task4/csvs"
    process_directory(directory_path, video_id)

#     files = glob.glob('E:/Task4/csvs/*')
#     for f in files:
#         os.remove(f)