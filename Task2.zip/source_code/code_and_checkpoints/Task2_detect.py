from ultralytics import YOLO
import cv2
import os
import json
import sys
import torch
import time
import numpy as np
import pandas as pd
import ultralytics.utils.torch_utils
import matplotlib.pyplot as plt


def main():
    if torch.cuda.is_available:
        flag=True
    else:
        flag=False
    frame_count = 0
    model_flops=8.7
    fps = 0
    flops = 0
    arguments = sys.argv[1:]
    directory = str(arguments[0])
    model_path = directory+"/source_code/code_and_checkpoints/"+"best.pt"
    # Load the YOLOv8 model with the pre-trained weights
    model = YOLO(model_path)
    video_id = arguments[1]
    # Open the video file
    video_path = directory + "data/" + str(video_id) + ".mp4"
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error: Video capture not opened")
        exit()

    path = directory + "Predictions/" + "test_video_"+str(video_id)
    labels_file_path = path + "/labels/"

    if not os.path.exists(labels_file_path):
        # If not, create it
        os.makedirs(labels_file_path)

    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # You can choose other codecs based on your preference
    output_video_path = path + "/" +str(video_id) + ".mp4"
    out = cv2.VideoWriter(output_video_path, fourcc, 30.0, (int(cap.get(3)), int(cap.get(4))))

    detections_list = []
    use_gpu = torch.cuda.is_available()

    while True:
        start_time = time.time()
        ret, frame = cap.read()
        if not ret:
            break
        if ret:

            # Open a text file for writing
            output_txt_path = labels_file_path + str(video_id) + "_frame_"+str(frame_count)+".txt"
            with open(output_txt_path, 'w') as txt_file:
            # Run YOLOv8 tracking on the frame, persisting tracks between frames
                results = model.predict(source=frame,conf=0.45)
                names = model.names
                # Get the boxes and predicted classes
                boxes = results[0].boxes.xywh.cpu()
                pred = [names[int(c)] for r in results for c in r.boxes.cls]


                # Write information to the text file
                for count, detection in enumerate(results[0].boxes.data.tolist()):
                    x1, y1, x2, y2, score, class_id = detection

                    detection_dict = {
                        "bbox": ['%.2f' % x1,'%.2f' % y1,'%.2f' % x2,'%.2f' % y2],
                        "class_label": int(class_id),
                        "image_id": frame_count,
                        "confidence_score": '%.5f' % score
                    }
                    txt_file.write(f"{int(class_id)} {x1} {y1} {x2} {y2} \n")

                # Visualize the results on the frame
                annotated_frame = results[0].plot()
                detections_list.append(detection_dict)

            # Write the annotated frame to the output video
                cv2.putText(annotated_frame, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
                if(flag==True):
                    cv2.putText(annotated_frame, f"FLOPS: {flops:.2f}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
                else:
                    cv2.putText(annotated_frame, f"FLOPS: {model_flops:.2f}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0),
                            2)


                out.write(annotated_frame)

                frame_count += 1

            # Break the loop if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        # Calculate FPS every frame
        end_time = time.time()
        elapsed_time = end_time - start_time
        fps = 1.0 / elapsed_time

        if use_gpu:
            flops = torch.cuda.memory_allocated() * 2 / elapsed_time
        else:
            flops = 8.7  # Default value if GPU is not available


    output_json_path = path + "/" +str(video_id) + "_detections.json"
    with open(output_json_path, 'w') as json_file:
        json.dump(detections_list, json_file, indent=4)


# Release everything when the job is finished
    cap.release()
    out.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()

