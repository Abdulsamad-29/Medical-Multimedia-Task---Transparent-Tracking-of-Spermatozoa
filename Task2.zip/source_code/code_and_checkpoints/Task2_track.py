import time
import torch
import os
import sys
from ultralytics import YOLO
import cv2
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import ultralytics.utils.torch_utils
from collections import defaultdict

def main():
    frame_count = 0
    fps = 0
    flops = 0
    arguments = sys.argv[1:]
    directory = str(arguments[0])
    model_path = directory+"/source_code/code_and_checkpoints/"+"best.pt"
    # Load the YOLOv8 model with the pre-trained weights
    model = YOLO(model_path)

    video_id = arguments[1]
    # Open the video file
    video_path = directory + "data/" + str(video_id) + ".mp4"
    cap = cv2.VideoCapture(video_path)

    path = directory + "Predictions/" + "test_video_"+str(video_id)
    labels_file_path = path + "/labels_ftid/"

    tracking_id = []
    track_history = defaultdict(lambda: [])

    if not cap.isOpened():
        print("Error: Video capture not opened")
        exit()


    if not os.path.exists(labels_file_path):
        # If not, create it
        os.makedirs(labels_file_path)


    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # You can choose other codecs based on your preference
    output_video_path = path + "/" + str(video_id) + "_tracking.mp4"
    out = cv2.VideoWriter(output_video_path, fourcc, 30.0, (int(cap.get(3)), int(cap.get(4))))
    use_gpu = torch.cuda.is_available()

    while True:
        start_time = time.time()
        ret, frame = cap.read()

        if not ret:
            break
        if ret:

            output_txt_path = labels_file_path + str(video_id) + "_frame_" + str(frame_count) + ".txt"
            with open(output_txt_path, 'w') as txt_file:
                # Run YOLOv8 tracking on the frame, persisting tracks between frames
                results = model.track(frame, tracker='bytetrack.yaml', persist=True)
                shape = frame.shape
                names = model.names
                # Get the boxes and track IDs
                boxes = results[0].boxes.xywh.cpu()
                track_ids = results[0].boxes.id.int().cpu().tolist()
                pred = [names[int(c)] for r in results for c in r.boxes.cls]
                #Write information to the text file
                for count, i in enumerate(pred):
                    txt_file.write(f"{track_ids[count]} {i} {np.array(boxes[count][0])} {np.array(boxes[count][1])} {np.array(boxes[count][2])} {np.array(boxes[count][3])} \n")
                # Visualize the results on the frame
                annotated_frame = results[0].plot()
                frame_count += 1

                # Plot the tracks
                for box, track_id in zip(boxes, track_ids):
                    x, y, w, h = box
                    track = track_history[track_id]
                    tracking_id.append(track_id)
                    track.append((float(x), float(y)))  # x, y center point

                    if len(track) > 30:  # retain 90 tracks for 90 frames
                        track.pop(0)

                    # Draw the tracking lines
                    points = np.hstack(track).astype(np.int32).reshape((-1, 1, 2))
                    cv2.polylines(annotated_frame, [points], isClosed=False, color=(250, 0, 0), thickness=3)

                    # Write the annotated frame to the output video
                cv2.putText(annotated_frame, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0),
                            2)


                cv2.putText(annotated_frame, f"FLOPS: {flops:.2f}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                                (0, 0, 0), 2)


                # Write the annotated frame to the output video
                out.write(annotated_frame)

            # Break the loop if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        # Calculate FPS & FLOPS every frame
        end_time = time.time()
        elapsed_time = end_time - start_time
        fps = 1.0 / elapsed_time
        if use_gpu:
            flops = torch.cuda.memory_allocated() * 2 / elapsed_time
        else:
            flops = 8.7  # Default value if GPU is not available

    # Release everything when the job is finished
    cap.release()
    out.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()