python D:/Task2/source_code/code_and_checkpoints/Task2_detect.py "$@"
python D:/Task2/source_code/code_and_checkpoints/Task2_track.py "$@"