python D:/Task1/source_code/code_and_checkpoints/Task1_detect.py "$@"
python D:/Task1/source_code/code_and_checkpoints/Task1_track.py "$@"